from distutils.core import setup

setup(
    name='test',
    version='1.0.0',
    py_modules = ['test'],
    author='shihao',
    author_email='chensh@udcredit.com',
    url='http://www.baidu.com',
    description='just helloworld'
)